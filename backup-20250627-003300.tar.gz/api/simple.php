<?php echo "PHP funcionando"; ?>
